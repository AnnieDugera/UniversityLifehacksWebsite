/*
connecto to db & returen info

For like, need to create col in DB
 */
package com.fyp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author macke
 */
public class HackDAO {
    public HackDAO(){
    
    }
    
    
    
    
    
    public ArrayList<Hack> getHacks (){
        ArrayList<Hack> hacks = new ArrayList<Hack>();
        
        Connection con = null; 
        Statement stmt = null;
        String dbURL = "jdbc:mysql://mysql1.it.nuigalway.ie:3306/mydb5240";
        String uname = "mydb5240da";
        String pword = "fy2zap";
        
        try{
          con = DriverManager.getConnection(dbURL, uname, pword);
          stmt = (Statement) con.createStatement();
          ResultSet rs = stmt.executeQuery("SELECT * FROM hack ORDER BY tipID");
          while (rs.next()){
              //one cz name is first feild in tbale 
              Hack u = new Hack(rs.getString(1), rs.getString(2),rs.getInt(3),rs.getInt(4));
              hacks.add(u); 
          }
          
        } catch (SQLException ex) {
            Logger.getLogger(HackDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return hacks;
    }
    public void updatelikes(int tipID, int like){
         //indos
        Connection con = null; 
        Statement stmt = null;
        String dbURL = "jdbc:mysql://mysql1.it.nuigalway.ie:3306/mydb5240";
        String uname = "mydb5240da";
        String pword = "fy2zap";
        
        try{
          con = DriverManager.getConnection(dbURL, uname, pword);
          stmt = (Statement) con.createStatement();
          String sql  = "UPDATE hack SET likes = "+like+" WHERE tipID = "+tipID;
          int rs= stmt.executeUpdate(sql);
         // String sql = "UPDATE hack SET likes = ? WHERE tipID = ?";
        //  PreparedStatement ps = con.prepareStatement(sql);
        //  ps.setInt(1, like);
        //  ps.setInt(2, tipID);
        //  int rs = ps.executeUpdate(sql);
          
          
        } catch (SQLException ex) {
            Logger.getLogger(HackDAO.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
}

